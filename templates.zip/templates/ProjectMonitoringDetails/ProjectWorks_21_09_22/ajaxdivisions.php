<!-- <option value="">Select division</option> -->
<option value = "<?php echo $division['division_id']; ?>"><?php echo $division['division_name']; ?></option>
<?php //echo $this->Form->control('division_id', ['type' => 'hidden', 'value'=>$division['division_id']]); ?>



